Comment jouer au jeu sur Windows ?

1. Décompresser l'archive (attention à laisser tous les fichiers dans un même document)
2. Lancer `My project.exe`

PS : Vous pouvez créez un raccourci de l'application `My project.exe` pour le lancer depuis votre bureau.
